import React from 'react'
import { Link } from 'react-router-dom'


const Sidebar = () => {
    return (
        <>
            <div className="h-screen flex ">
                <div className="bg-gray-900 lg:flex md:w-64 md:flex-col overflow-y-hidden">
                    <div className="flex-col pt-5 flex overflow-y-hidden">
                        <div className="h-full flex-col justify-between px-4 flex">
                            <div className="space-y-4 mt-16">
                                
                                <ul className="space-y-2">
                                    <li>
                                    <Link to="/" className="text-white rounded-lg    px-4 py-2.5 block transition-all duration-200">
                                            Category
                                            </Link>
                                    </li>
                                    <li>

                                        <Link to="/subcategory" className="text-gray-300  px-4 py-2.5 block transition-all duration-200">
                                            Sub Category
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to="/getproduct" className="text-gray-300  px-4 py-2.5 block transition-all duration-200">
                                            Product
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
      
        </>
    )
}

export default Sidebar